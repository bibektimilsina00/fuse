module.exports=[11230,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_workflows_%5Bid%5D_page_actions_17de0ebb.js.map