module.exports=[34426,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_oauth_callback_page_actions_dddd0b04.js.map