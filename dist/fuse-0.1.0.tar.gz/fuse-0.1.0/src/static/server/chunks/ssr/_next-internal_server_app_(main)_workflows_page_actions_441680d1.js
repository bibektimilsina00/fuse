module.exports=[79788,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28main%29_workflows_page_actions_441680d1.js.map