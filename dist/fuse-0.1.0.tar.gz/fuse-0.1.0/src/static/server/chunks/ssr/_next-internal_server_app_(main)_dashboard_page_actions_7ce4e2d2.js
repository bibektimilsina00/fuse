module.exports=[21822,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28main%29_dashboard_page_actions_7ce4e2d2.js.map