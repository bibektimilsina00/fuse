module.exports=[97965,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28main%29_ai-create-example_page_actions_2f9be208.js.map