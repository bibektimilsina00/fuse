module.exports=[9838,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28main%29_settings_page_actions_33dd8d86.js.map